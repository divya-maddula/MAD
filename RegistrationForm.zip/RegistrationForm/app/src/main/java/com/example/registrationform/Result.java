package com.example.registrationform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Result extends AppCompatActivity {
    protected TextView tv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        tv=(TextView)findViewById(R.id.textView);
        Intent intent=getIntent();
        String id=intent.getSerializableExtra("Id").toString();
        if(id.equals("Reg")) {
            String s = (String) intent.getSerializableExtra("Val");
            tv.setText(s);
        }
        else
        {
            String s = (String) intent.getSerializableExtra("Dis");
            tv.setText(s);

        }
    }
}
