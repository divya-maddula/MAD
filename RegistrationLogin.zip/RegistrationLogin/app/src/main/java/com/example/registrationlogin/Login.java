package com.example.registrationlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    Databasehelper myDb;
    protected EditText editText;
    protected EditText editText5;
    protected Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myDb=new Databasehelper(this);
        editText5=(EditText)findViewById(R.id.editText5);
        editText=(EditText)findViewById(R.id.editText4);
        button3=(Button)findViewById(R.id.button3);
        Intent intent=getIntent();
        String s=intent.getSerializableExtra("Button").toString();
        Toast.makeText(getApplicationContext(),"Throuh"+s+"Button",Toast.LENGTH_SHORT).show();
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=editText.getText().toString();
                String p=editText5.getText().toString();
                Toast.makeText(Login.this,"Logged btn",Toast.LENGTH_LONG).show();
                Boolean res=myDb.checkUser(s1,p);
                if(res)
                {
                    Toast.makeText(Login.this,"Successfully Logged in",Toast.LENGTH_LONG).show();
                    Intent intent3=new Intent(Login.this,Result.class);
                    intent3.putExtra("Val","Welcome "+s1);
                    startActivity(intent3);
                }
                else
                {
                   Toast.makeText(Login.this,"Invalid Username or Password",Toast.LENGTH_LONG).show();
                }


            }
        });




    }
}
