package com.example.registrationform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Login extends AppCompatActivity {
    Databasehelper myDb;
    protected EditText editText;
    protected EditText editText1;
    protected Button button;
    protected TextView reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myDb=new Databasehelper(this);
        editText=(EditText)findViewById(R.id.editText);
        editText1=(EditText)findViewById(R.id.editText2);
        reg=(TextView)findViewById(R.id.textView);
        button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=editText.getText().toString();
                String p=editText1.getText().toString();
                boolean res=myDb.checkUser(s,p);
                if(res) {
                    Toast.makeText(Login.this,"Successfully Logged in",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Login.this, Result.class);
                    intent.putExtra("Id", "Log");
                    intent.putExtra("Dis", "Welcome:" + s + "\n\nYou have successfuly logged in");
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(Login.this,"Invalid Username or Password! Please Try again.",Toast.LENGTH_LONG).show();
                }
            }
        });
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(Login.this,MainActivity.class);
                startActivity(intent1);
            }
        });

    }
}
