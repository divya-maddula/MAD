package com.example.registrationform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Databasehelper myDb;
    protected EditText et1;
    protected EditText et2;
    protected EditText et3;
    protected EditText et4;
    protected EditText et5;
    protected Button button;
    protected TextView login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb=new Databasehelper(this);
        et1=(EditText)findViewById(R.id.editText);
        et2=(EditText)findViewById(R.id.editText2);
        et3=(EditText)findViewById(R.id.editText3);
        et4=(EditText)findViewById(R.id.editText4);
        et5=(EditText)findViewById(R.id.editText5);
        login=(TextView)findViewById(R.id.textView);
        button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=et1.getText().toString();
                String s2=et2.getText().toString();
                String s3=et3.getText().toString();
                String s4=et4.getText().toString();
                String s5=et5.getText().toString();
                if(!s4.equals(s5))
                {
                    Toast.makeText(getApplicationContext(),"Password an Confirm Password are not same",Toast.LENGTH_SHORT).show();

                }
                if(s4.equals(s5))
                {
                    boolean check=myDb.insertData(et1.getText().toString(),et2.getText().toString(),et3.getText().toString(),et4.getText().toString());
                    if(check)
                    {
                        Toast.makeText(MainActivity.this,"Successfully registered",Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(MainActivity.this,"Not registered.Please try again",Toast.LENGTH_LONG).show();
                    }
                    Intent intent=new Intent(MainActivity.this,Result.class);
                    intent.putExtra("Id","Reg");
                    intent.putExtra("Val","Welcome:"+s1+"\n\nEmail is:"+s2+"\n\nPhone Number is:"+s3+"\n\nYou have been sucessfully Registered");
                    startActivity(intent);
                }
            }
        });}
        public void onTextView(View v)
        {
            Intent intent1=new Intent(MainActivity.this,Login.class);
            startActivity(intent1);
        }

}
