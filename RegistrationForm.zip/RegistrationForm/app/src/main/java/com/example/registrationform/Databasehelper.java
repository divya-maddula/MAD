package com.example.registrationform;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Databasehelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Reg.db";
    public static final String TABLE_NAME = "Reg";
    public static final String c1 = "ID";
    public static final String c2 = "Name";
    public static final String c3 = "Email";
    public static final String c4 = "Phone";
    public static final String c5 = "Password";


    public Databasehelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,Name TEXT,Email TEXT,Phone TEXT ,Password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }

    public boolean insertData(String Name, String Email, String Phone, String Password) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(c2,Name);
        contentValues.put(c3,Email);
        contentValues.put(c4,Phone);
        contentValues.put(c5,Password);
        long r=db.insert(TABLE_NAME,null,contentValues);
        if(r==-1)
            return false;
        else
            return true;

    }
    public boolean checkUser(String un,String p)
    {
        String[] columns={c1};
        SQLiteDatabase db=getReadableDatabase();
        String selection=c2+"=?"+" and "+c5+"=?";
        String[] selectionArgs={un,p};
        Cursor cursor=db.query(TABLE_NAME,columns,selection,selectionArgs,null,null,null);
        int count=cursor.getCount();
        cursor.close();
        db.close();
        if(count>0)
            return  true;
        else
            return false;

    }
}

