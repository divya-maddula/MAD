package com.example.registrationlogin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Databasehelper myDb;
    protected EditText editText;
    protected EditText editText2;
    protected EditText editText3;
    protected EditText id;
    protected Button submit;
    protected Button login;
    protected Button show;
    protected Button update;
    protected Button delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb=new Databasehelper(this);
        editText=(EditText)findViewById(R.id.editText);
        editText2=(EditText)findViewById(R.id.editText2);
        editText3=(EditText)findViewById(R.id.editText3);
        id=(EditText)findViewById(R.id.editText6);
        submit=(Button)findViewById(R.id.button);
        login=(Button)findViewById(R.id.button2);
        show=(Button)findViewById(R.id.button4);
        update=(Button)findViewById(R.id.button5);
        delete=(Button)findViewById(R.id.button6);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=editText2.getText().toString();
                String s2=editText3.getText().toString();
                if(!s1.equals(s2))
                {
                    Toast.makeText(getApplicationContext(),"Password and Confirm Password are not same",Toast.LENGTH_SHORT).show();
                    s1=editText2.getText().toString();
                    s2=editText3.getText().toString();
                }
                if(s1.equals(s2)) {
                    boolean ch=myDb.insertData(editText.getText().toString(),editText2.getText().toString());
                    if(ch)
                        Toast.makeText(MainActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(MainActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();
                    Intent intent1 = new Intent(MainActivity.this, Login.class);
                    intent1.putExtra("Button", "Sub");
                    intent1.putExtra("Name", editText.getText().toString());
                    intent1.putExtra("Pwd", s1);
                    startActivity(intent1);
                }
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(MainActivity.this,Login.class);
                intent2.putExtra("Button","Log");
                startActivity(intent2);

            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res=myDb.getAllData();
                if(res.getCount()==0)
                {
                    showMessage("Error","Nothing Found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while (res.moveToNext())
                {
                    buffer.append("Id:"+res.getString(0)+"\n");
                    buffer.append("Name:"+res.getString(1)+"\n");
                    buffer.append("Password:"+res.getString(2)+"\n");
                }
                showMessage("Data",buffer.toString());
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isUpdate=myDb.updateData(id.getText().toString(),editText.getText().toString(),editText2.getText().toString());
                if(isUpdate)
                {
                    Toast.makeText(MainActivity.this,"Data updated",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Data couldn't be updated",Toast.LENGTH_LONG).show();
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedrows=myDb.deleteData(id.getText().toString());
                if(deletedrows>0)
                {
                    Toast.makeText(MainActivity.this,"Data deleted",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Data unable to delete",Toast.LENGTH_LONG).show();
                }

            }
        });
    }
    public void showMessage(String title,String msg)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(msg);
        builder.show();
    }
}
